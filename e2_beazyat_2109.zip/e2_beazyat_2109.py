word="bottles"
for i in range(99,0,-1):
    print(i,word,"of beer on the wall.")
    print(i,word,"of beer.")
    print("Take one down.")
    print("Pass it around.")
    if i==1:
        print("No more bottles of beer on the wall.")
    else :
        new_i=i-1
        if new_i==1:
            word="bottle"
        print("%d %s of beer o the wall." % (new_i,word))
    
        

