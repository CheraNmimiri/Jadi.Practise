vowels=["a","e","o",'u','i']
inv=[]
word=input("Provide a word to search for vowels:")
for i in word:
    if i in vowels:
        inv.append(i)
for j in set(inv):
    print(j)